<?php
$json ='["apple","orange","banana","strawberry"]';
$ar = json_decode($json);

echo $ar[0];
$json ='{"title":"JavaScript: The Defenitive Guide"
    ,"author":"David Flanagan"
    ,"edition": 6
}';

$book = json_decode($json);

echo $book -> title;
