<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'ajax_demo';

$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if($mysqli->connect_errno){
    printf("Failed to connect to database");
    exit();
}

$query="SELECT * FROM user";
$result=$mysqli->query($query)
    or die ($mysqli->error);

$response = array();
$posts = array ();
while($row=$result->fetch_assoc())
{
    $id_ajax_demo=$row['id'];
    $firstname_ajax_demo=$row['FirstName'];
    $lastname_ajax_demo=$row['LastName'];
    $age_ajax_demo=$row['Age'];
    $hometown_ajax_demo=$row['Hometown'];
    $job_ajax_demo=$row['Job'];
    $posts[] = array(
        'id' => $id_ajax_demo,
        'FirstName' => $firstname_ajax_demo,
        'LastName' => $lastname_ajax_demo,
        'Age' => $age_ajax_demo,
        'Hometown' => $hometown_ajax_demo,
        'Job' => $job_ajax_demo);
}

$response = $posts;

$fp = fopen('data-api-ajaxdemo.json', 'w');
fwrite($fp, json_encode($response, JSON_PRETTY_PRINT));
fclose($fp);
header('Location: data-api-ajaxdemo.json');
?>